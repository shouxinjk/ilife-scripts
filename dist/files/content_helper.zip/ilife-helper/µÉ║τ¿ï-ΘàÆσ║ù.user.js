// ==UserScript==
// @name         携程-酒店
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  extract hotel
// @author       sx
// @require http://code.jquery.com/jquery-latest.js
// @require http://118.190.75.121/dist/waitForKeyElements.min.js
// @require http://118.190.75.121/dist/md5.min.js
// @require http://www.biglistoflittlethings.com/dist/util.js?v=2.74
// @icon    http://www.shouxinjk.net/favicon.ico
// @match        http://hotels.ctrip.com/hotels/*
// @match        https://hotels.ctrip.com/hotels/*.html*
// @grant        none
// ==/UserScript==

//示例URL
//http://hotels.ctrip.com/hotels/20058441.html#ctm_ref=www_hp_his_lst
//https://hotels.ctrip.com/hotels/375513.html#ctm_ref=hod_hp_hot_dl_n_28_6
this.$ = this.jQuery = jQuery.noConflict(true);//important: to remove jQuery conflict

var debug = true;
var automation = false;

var schema={
//TODO: validate and commit
};

var data={
    task:{
        user:"userid",//注册的编码
        executor:"machine",//机器标识
            timestamp:new Date().getTime(),//时间戳
            url:window.location.href//原始浏览地址
    },
    url:web(window.location.href),
    type:"hotel",
    source:"ctrip",
    category:"酒店",
    title:null,
    summary:"",
    price:{
        bid:null,
        sale:null
    },
    images:[],
    tags:[],
    distributor:{
        name:"携程"
    },
    rank:{
        score:null,
        base:null,
        count:null,
        match:0.75//by default
    },
    link:{
        web:web(window.location.href),//web浏览地址
        wap:wap(window.location.href)//移动端浏览地址，默认与web一致
    },
    props:[]
};
var keys=[];//保存prop-key用于排重
var seed={//an example for extract urls
    task:{
        user:"userid",//注册的编码
        executor:"machine",//机器标识
        url:window.location.href//原始浏览地址
    },
    source:"ctrip",
    type:"hotel",
    url:document.location.href
};

var startTime = new Date().getTime();//用时间戳控制页面切换时间，开始时间
var commitTime = new Date().getTime()+5*1000;//记录最近一次提交数据时间，每次commit将修改改时间
var durationTime = Math.floor(Math.random()*10+5)*1000;//控制间隔毫秒数 5-15秒
var idleTime = 1000;//提交后等待1秒

//var timerId = setInterval(next, 500);//需要设置页面跳转检查

(function() {
    'use strict';
    waitForKeyElements ("h1.detail-headline_name", title);
    waitForKeyElements (".detail-headline_desc_text", summary);
    waitForKeyElements ("button[tagtype='tagTheme'] span", tags);
    waitForKeyElements (".detail-headalbum_bigpicImg", logo);
    waitForKeyElements (".detail-headalbum_item .m-img div[style]", images);
    waitForKeyElements (".detail-headreview_score_value",rank_score);
    waitForKeyElements (".detail-headreview_all",rank_count);
    waitForKeyElements (".detail-head-price_delete_price",price_bid);
    waitForKeyElements (".detail-head-price_price",price_sale);//售价
    waitForKeyElements ("select.select_ctrip",tags_triptype);
    waitForKeyElements ("li:contains('开业：')",props);
    waitForKeyElements ("li:contains('装修时间：')",props);
    waitForKeyElements ("li:contains('客房数：')",props);
    waitForKeyElements ("i[type='star']",stars);//星级
    waitForKeyElements (".facilityDesc",facility);//服务设施
    waitForKeyElements (".breakfastTxt",breakfast);//早餐
    waitForKeyElements (".checkTime",checkTime);//入住及退房
    waitForKeyElements ("i[type$='flight']:first",airportDistance);//机场距离
    waitForKeyElements ("i[type$='train']:first",trainDistance);//车站距离
    waitForKeyElements ("i[type$='subway']:first",subwayDistance);//地铁距离
    waitForKeyElements (".detail-headline_position_text",address);//地址信息
    //commitUrl(seed);//here is an example
})();

function address(jNode){
    var addr = {};
    addr["地址"] = jNode.text().replace(/，/g," ");
    data.props.push(addr);
}

function airportDistance(jNode){
    transportDistance("到机场距离",jNode);
}

function trainDistance(jNode){
    transportDistance("到车站距离",jNode);
}

function subwayDistance(jNode){
    transportDistance("到地铁距离",jNode);
}

function transportDistance(name,jNode){
    var txt = jNode.parent().find("span.item_distance").text();
    var distance = {};
    distance[name]=txt;
    data.props.push(distance);
}

function checkTime(jNode){
    extProp("入住及退房",jNode);
}

function breakfast(jNode){
    extProp("早餐类型",jNode);
}

function facility(jNode){
    extProp("服务设施",jNode);
}

//处理以空格分隔的字符串属性，如设施、餐食、POI等
function extProp(name,jNode){
    var extProp={};
    extProp[name]="";
    for(var j in data.props){
        var prop = data.props[j];
        var _key = "";
        for ( var key in prop){//从prop内获取key
            _key = key;
            break;
        }
        if(_key==name){
            extProp = data.props[j];
            data.props.splice(j, 1);//先删除该元素
            break;
        }
    }
    extProp[name]=extProp[name]+" "+jNode.text();
    data.props.push(extProp);
}

function stars(jNode){
    var starPropName = "星级";
    var star={};
    star[starPropName]=$("i[type='star']").length;
    data.props.push(star);//把最新的加入
    for(var j in data.props){
        var prop = data.props[j];
        var _key = "";
        for ( var key in prop){//从prop内获取key
            _key = key;
            break;
        }
        if(_key!=starPropName)
            continue;
        data.props.splice(j, 1);//先删除该元素
        data.props.push(star);//把最新的加入
        break;
    }
}

function props(jNode){
    var txt = jNode.text().split('：');
    if(txt.length>1){
        var key = txt[0];
        var value = Number(txt[1]);
        var prop = {};
        prop[key]=value;
        if(key.trim().length>0 && keys.indexOf(key)<0){
            data.props.push(prop);
            keys.push(key);
        }
        commit("props");
    }
}

function title(jNode){
    //console.log("titleEl",$("h2.cn_n"),jNode);
    data.title = jNode.text();
    commit("title");
}

function summary(jNode){
    data.summary = jNode.text().replace(/\s+/g,"");
    commit("summary");
}

function tags(jNode){
    var tag = jNode.text().replace(/\(\d+\)/g,"");
    if(data.tags.indexOf(tag)<0)
        data.tags.push(tag);
    commit("tags");
}

function tags_triptype(jNode){
    var types = [];//出游类型标签
    jNode.find("option[value!='-1']:parent").each(function(){//获取所有出游类型，包括类型及数量
        var t = $(this).text().split(/[\(\)]+/);
        var c = $(this).text().match(/\d+/);
        var type = {type:t[0],count:parseInt(c[0])};
        types.push(type);
    });
    types = types.sort(function (a, b) {//根据出游数量排序
        return a.count > b.count ? -1 : 1;
    });
    for(var i=0;i<types.length && i<3;i++){//取前3个标签
        data.tags.push(types[i].type);
    }
    commit("tags_triptype");
}

function logo(jNode){
    var img = fullUrl(jNode.attr("src"));
    data.logo = img;
    if(data.images.indexOf(img)<0)
        data.images.push(img);
    commit("logo");
}

function images(jNode){
    var img = fullUrl(jNode.attr("style").match(/url\("[^"]+/g)[0].replace('url("',""));
    if(data.images.indexOf(img)<0)
        data.images.push(img);
    commit("images");
}

function rank_score(jNode){
    var score = jNode.text().match(/\d\.*\d*/g);//客户点评：4.2分，总分5分。
    data.rank.score = Number(score[0]);
    data.rank.base = 5;
    commit("rank_score");
}

function rank_count(jNode){
    var count = jNode.text().match(/\d+/g);
    data.rank.count = Number(count[0]);
    commit("rank_count");
}

function price_sale(jNode){
    var price = jNode.text().replace(/,/g,"").match(/\d+\.*\d*/g);
    data.price.sale = Number(price[0]);
    commit("price_sale");
}

function price_bid(jNode){
    var price = jNode.text().replace(/,/g,"").match(/\d+\.*\d*/g);
    data.price.bid = Number(price[0]);
    commit("price_bid");
}

//转换为web链接地址：需要去除附加信息，确保唯一性
//转换后: https://hotels.ctrip.com/hotels/435194.html
function web(link){
    var id = link.match(/\d+.html/)[0];//匹配后返回：435194.html
    return "https://hotels.ctrip.com/hotels/"+id;
}

//转换为移动链接地址
//wap: https://m.ctrip.com/webapp/hotel/HotelDetail/76246019.html
function wap(link){
    var id = link.match(/\d+.html/)[0];//匹配后返回：20058441.html
    return "https://m.ctrip.com/webapp/hotel/HotelDetail/"+id;
}

//commit data
function commit(key){
    if(validate()){
        if(debug)console.log("validate succeed. [prop]"+key,data);
        commitData(data,next);
        commitTime = new Date().getTime();
    }else{
        if(debug)console.log("validate failed.[prop]"+key,data);
    }
}

//validate data collected
function validate(){
    //TODO use json schema to validate data
    return data.title && data.summary.length>0 && data.images.length>0 && data.price.sale && data.tags.length>0;
}

//navigate to next url
function next(){
    var duration = new Date().getTime()-startTime;
    var idle = new Date().getTime()-commitTime;
    var isPageTimeout = duration > durationTime && idle > idleTime;
    //console.log("\n\n crawling ...",duration,durationTime,idle,idleTime,isPageTimeout);
    if( automation && isPageTimeout ){_next();}
}



