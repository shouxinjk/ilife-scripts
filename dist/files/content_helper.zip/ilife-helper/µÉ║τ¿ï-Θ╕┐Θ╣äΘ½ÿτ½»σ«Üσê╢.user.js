// ==UserScript==
// @name         携程-鸿鹄高端定制
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  extract hotel
// @author       sx
// @require http://code.jquery.com/jquery-latest.js
// @require http://118.190.75.121/dist/waitForKeyElements.min.js
// @require http://118.190.75.121/dist/md5.min.js
// @require https://www.biglistoflittlethings.com/dist/util.min.js?v=2.1
// @icon    http://www.shouxinjk.net/favicon.ico
// @match        https://vacations.ctrip.com/customtravel/hhtravel/tourlineDetail?lineId=*
// @match        http://vacations.ctrip.com/customtravel/hhtravel/tourlineDetail?lineId=*
// @grant        none
// ==/UserScript==

//示例URL
//https://vacations.ctrip.com/customtravel/hhtravel/tourlineDetail?lineId=20914190&ctm_ref=vactang_page_5872
this.$ = this.jQuery = jQuery.noConflict(true);//important: to remove jQuery conflict

var debug = true;
var automation = false;

var schema={
//TODO: validate and commit
};

var data={
    task:{
        user:"userid",//注册的编码
        executor:"machine",//机器标识
            timestamp:new Date().getTime(),//时间戳
            url:window.location.href//原始浏览地址
    },
    url:web(window.location.href),
    type:"line",
    source:"ctrip",
    title:null,
    summary:"",
    price:{
        bid:null,
        sale:null
    },
    images:[],
    tags:[],
    distributor:{
        name:"携程"
    },
    rank:{
        score:5,
        base:5,
        count:null,
        match:0.75//by default
    },
    link:{
        web:web(window.location.href),//web浏览地址
        wap:wap(window.location.href)//移动端浏览地址，默认与web一致
    }
};

var seed={//an example for extract urls
    task:{
        user:"userid",//注册的编码
        executor:"machine",//机器标识
        url:window.location.href//原始浏览地址
    },
    source:"ctrip",
    type:"hotel",
    url:document.location.href
};

var startTime = new Date().getTime();//用时间戳控制页面切换时间，开始时间
var commitTime = new Date().getTime()+5*1000;//记录最近一次提交数据时间，每次commit将修改改时间
var durationTime = Math.floor(Math.random()*10+5)*1000;//控制间隔毫秒数 5-15秒
var idleTime = 1000;//提交后等待1秒

//var timerId = setInterval(next, 500);//需要设置页面跳转检查

(function() {
    'use strict';
    waitForKeyElements ("h2.product_title", title);
    waitForKeyElements (".featureText", summary);
    waitForKeyElements (".bold_text", tags);
    waitForKeyElements (".product_tips_mod",tags_feature);
    //waitForKeyElements (".detail-headalbum_bigpicImg", logo);
    waitForKeyElements (".j_imgContent img", images);
    //waitForKeyElements (".detail-headreview_score_value",rank_score);
    //waitForKeyElements (".detail-headreview_all",rank_count);
    //waitForKeyElements (".detail-head-price_delete_price",price_bid);
    waitForKeyElements (".price_num",price_sale);//售价
    //commitUrl(seed);//here is an example
})();

function title(jNode){
    //console.log("titleEl",$("h2.cn_n"),jNode);
    data.title = jNode.text();
    commit("title");
}

function summary(jNode){
    data.summary += jNode.text().replace(/\s+/g,"")+"<br/>";
    commit("summary");
}

function tags(jNode){
    var tag = jNode.text().replace(/\(\d+\)/g,"");
    if(data.tags.indexOf(tag)<0)
        data.tags.push(tag);
    commit("tags");
}

function tags_feature(jNode){
    console.log("tags_feature",jNode.text());
    var tags = jNode.text().trim().split("+");
    for(var i=0;i<tags.length;i++){
        var tag = tags[i].trim();
        if(tag.length>0 && data.tags.indexOf(tag)<0)
            data.tags.push(tag);
    }
    commit("tags_featur");
}

function images(jNode){
    var img = fullUrl(jNode.attr("src"));
    if(!data.logo)
        data.logo = img;
    if(data.images.indexOf(img)<0)
        data.images.push(img);
    commit("images");
}

function rank_score(jNode){
    var score = jNode.text().match(/\d\.*\d*/g);//客户点评：4.2分，总分5分。
    data.rank.score = Number(score[0]);
    data.rank.base = 5;
    commit("rank_score");
}

function rank_count(jNode){
    var count = jNode.text().match(/\d+/g);
    data.rank.count = Number(count[0]);
    commit("rank_count");
}

function price_sale(jNode){
    var price = jNode.text().replace(/,/g,"").replace(/万/g,"*10000").match(/\d+\.*\d*\*\d*/g);
    data.price.sale = Number(eval(price[0]));
    commit("price_sale");
}

function price_bid(jNode){
    var price = jNode.text().replace(/,/g,"").match(/\d+\.*\d*/g);
    data.price.bid = Number(price[0]);
    commit("price_bid");
}

//转换为web链接地址：需要去除附加信息，确保唯一性
//转换后: https://vacations.ctrip.com/customtravel/hhtravel/tourlineDetail?lineId=20914190
function web(link){
    var id = link.match(/lineId=\d+/)[0];//匹配后返回：lineId=663734
    return "https://vacations.ctrip.com/customtravel/hhtravel/tourlineDetail?"+id;
}

//转换为移动链接地址
//wap: https://m.ctrip.com/webapp/vacations/dingzhi/hhtravel/tourlineDetail?lineId=20914190
function wap(link){
    var id = link.match(/lineId=\d+/)[0];//匹配后返回：lineId=663734
    return "https://m.ctrip.com/webapp/vacations/dingzhi/hhtravel/tourlineDetail?"+id;
}

//commit data
function commit(key){
    if(validate()){
        if(debug)console.log("validate succeed. [prop]"+key,data);
        commitData(data,next);
        commitTime = new Date().getTime();
    }else{
        if(debug)console.log("validate failed.[prop]"+key,data);
    }
}

//validate data collected
function validate(){
    //TODO use json schema to validate data
    return data.title && data.summary.length>0 && data.images.length>0 && data.price.sale && data.tags.length>0;
}

//navigate to next url
function next(){
    var duration = new Date().getTime()-startTime;
    var idle = new Date().getTime()-commitTime;
    var isPageTimeout = duration > durationTime && idle > idleTime;
    //console.log("\n\n crawling ...",duration,durationTime,idle,idleTime,isPageTimeout);
    if( automation && isPageTimeout ){_next();}
}







