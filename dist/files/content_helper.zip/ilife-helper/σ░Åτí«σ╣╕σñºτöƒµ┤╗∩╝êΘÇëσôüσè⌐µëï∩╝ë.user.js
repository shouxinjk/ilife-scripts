// ==UserScript==
// @name         小确幸大生活（选品助手）
// @namespace    https://www.biglistoflittlethings.com/
// @version      1.0
// @description  提供商品列表及选品功能， 帮助内容编辑者根据内容主题及用户筛选合适的商品。
// @author       sx
// @require http://code.jquery.com/jquery-latest.js
// @require http://118.190.75.121/dist/js.cookie.min.js
// @require http://118.190.75.121/dist/waitForKeyElements.min.js
// @require http://118.190.75.121/dist/md5.min.js
// @require http://www.biglistoflittlethings.com/dist/util.min.js?v=2.5
// @require http://www.biglistoflittlethings.com/dist/toolbar/crawler.min.js?v=2.0
// @icon    http://www.shouxinjk.net/favicon.ico
// @resource   IMPORTED_CSS https://biglistoflittlethings.com/ilife-web-wx/broker/css/broker.css
// @match      https://vacations.ctrip.com/travel/detail/*
// @match      http://vacations.ctrip.com/travel/detail/*
// @match        http://hotels.ctrip.com/hotels/*
// @match        https://hotels.ctrip.com/hotels/*
// @match        https://vacations.ctrip.com/customtravel/hhtravel/tourlineDetail?lineId=*
// @match        http://vacations.ctrip.com/customtravel/hhtravel/tourlineDetail?lineId=*
// @match        https://huodong.ctrip.com/ottd-activity/dest/*.html*
// @match        https://activity.ctrip-ttd.hk/ottd-activity/dest/*.html*
// @match      https://detail.tmall.com/item.htm*
// @match      https://detail.tmall.hk/hk/item.htm*
// @match      https://item.jd.com/*
// @match        https://traveldetail.fliggy.com/item.htm?*
// @match        https://item.taobao.com/item.htm?*
// @match        https://detail.vip.com/*
// @match        http://detail.vip.com/*
// @match        https://goods.kaola.com.hk/product/*
// @match        https://goods.kaola.com/product/*
// @match        http://you.163.com/item/detail?id=*
// @match        https://you.163.com/item/detail?id=*
// @match        http://vacations.lvmama.com/w/*
// @match        https://www.ly.com/scenery/BookSceneryTicket_*
// @match        https://www.ly.com/youlun/tours-*
// @match        https://*.package.qunar.com/user/id=*
// @match        https://*.package.qunar.com/user/detail.jsp?id=*
// @match        https://*.package.qunar.com/user/detail.jsp?abt=a&id=*
// @match        http://www.aoyou.com/cruise/c*
// @match        http://www.aoyou.com/domesticgroup/*
// @match        https://www.1919.cn/p/*
// @match        https://product.suning.com/*
// @grant      GM_getResourceText
// @grant      GM_addStyle
// ==/UserScript==

(function() {
    'use strict';
    const sx_css = GM_getResourceText("IMPORTED_CSS");
    GM_addStyle(sx_css);
    waitForKeyElements ("body", sxInitialize);
})();


