// ==UserScript==
// @name         小确幸大生活（内容助手）
// @namespace    https://www.biglistoflittlethings.com/
// @version      1.0
// @description  提供商品列表及选品功能， 帮助内容编辑者根据内容主题及用户筛选合适的商品。
// @author       sx
// @require http://code.jquery.com/jquery-latest.js
// @require http://118.190.75.121/dist/js.cookie.min.js
// @require http://118.190.75.121/dist/waitForKeyElements.min.js
// @require http://118.190.75.121/dist/md5.min.js
// @require http://118.190.75.121/dist/util.min.js?v=1.1
// @require https://www.biglistoflittlethings.com/dist/toolbar/mp.min.js?v=1.2
// @icon    http://www.shouxinjk.net/favicon.ico
// @resource   IMPORTED_CSS https://biglistoflittlethings.com/ilife-web-wx/broker/css/broker.css
// @match        https://mp.weixin.qq.com/cgi-bin/appmsg?t=media/appmsg_edit&action=edit*
// @match        https://mp.weixin.qq.com/cgi-bin/appmsg?t=media/appmsg_edit_v2&action=edit*
// @match        https://mp.toutiao.com/profile_v4/graphic/publish*
// @match        https://om.qq.com/main/creation/article*
// @grant      GM_getResourceText
// @grant      GM_addStyle
// ==/UserScript==

(function() {
    'use strict';
    const sx_css = GM_getResourceText("IMPORTED_CSS");
    GM_addStyle(sx_css);
    waitForKeyElements ("body", sxInitialize);
})();
